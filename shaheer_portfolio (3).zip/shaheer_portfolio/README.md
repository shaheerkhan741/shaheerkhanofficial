# Shaheer Khan — Personal Portfolio

A responsive single-page portfolio built with plain HTML, CSS, and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — layout, colors, responsive design, and animations
- `script.js` — mobile navigation, reveal effects, footer year, and contact-form helper

## Run locally
1. Download and extract the project ZIP.
2. Open the `shaheer_portfolio` folder.
3. Double-click `index.html` to open it in your browser.

For a local development server, open the folder in VS Code and use the Live Server extension, or run `python -m http.server 8000` in the folder and visit `http://localhost:8000`.

## Customize
- Replace the `SK` initials placeholder in `index.html` with a real profile photo if desired.
- Update text and contact information in `index.html`.
- Change theme colors near the top of `style.css` in the `:root` variables.
- Update skill descriptions as your experience grows.

## Contact form note
The contact form validates the fields and opens the visitor's default email app with a prefilled message. It does not send email directly. For direct submissions, connect a backend or trusted form service.

## Privacy
This website includes a phone number and email address supplied for the portfolio. Consider whether you want your personal phone number publicly visible before publishing the site.


## Your profile photo and résumé
- `profile.jpg` is the profile photo you provided and is displayed in the hero section. Keep it beside `index.html`.
- `resume.pdf` is the résumé you uploaded. The “Download résumé” button downloads it, and the contact section also links to the PDF. Keep it beside `index.html`.
